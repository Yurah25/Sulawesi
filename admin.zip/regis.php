<?php
include 'config/database.php';

if (isset($_POST['register'])) {
    $username = mysqli_real_escape_string($conn, $_POST['username']);
    $email = mysqli_real_escape_string($conn, $_POST['email']);
    $password = $_POST['password'];
    $confirm_password = $_POST['confirm-password']; 

    
    $cek = mysqli_query($conn, "SELECT * FROM users WHERE email = '$email'");
    if (mysqli_num_rows($cek) > 0) {
        echo "<script>alert('Email sudah terdaftar!');</script>";
    } elseif ($password !== $confirm_password) {
        echo "<script>alert('Konfirmasi password tidak cocok!');</script>";
    } else {
        $pass_hash = password_hash($password, PASSWORD_DEFAULT);
   
        $query = "INSERT INTO users (username, email, password, role) VALUES ('$username', '$email', '$pass_hash', 'user')";
        
        if (mysqli_query($conn, $query)) {
            echo "<script>alert('Registrasi Sukses! Silakan Login.'); window.location='login.php';</script>";
        } else {
            echo "<script>alert('Gagal: " . mysqli_error($conn) . "');</script>";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="assets/css/regis.css">
    <title>Registrasi-page</title>
</head>
<body>
    <div class="deskripsi">
    <h1>Join the Journey Across Sulawesi</h1>
    <p>Create your account and explore the culture, cuisine, and tourism of Sulawesi in one platform</p>
    </div>
    <form action="" method="post">
        <a class="kembali" href="index.php">kembali</a>
        <h1>Sign up</h1>
        <label for="email">Username </label>
        <input type="text" id="username" name="username" placeholder="Masukkan Username">
        <label for="email">Email </label>
        <input type="email" id="email" name="email" placeholder="Masukkan Email">
        <label for="password">Password</label>
        <input type="password" id="password" name="password" placeholder="Masukkan Password">
        <label for="confirm-password">Confirm Password</label>
        <input type="password" id="confirm-password" name="confirm-password" placeholder="Masukkan Ulang Password">
        <input type="submit" id="submit" name="register" value="Create Account">
        <p>Already have an account?<a href="login.php" >Login in</a></p>
    </form>
</body>
</html>