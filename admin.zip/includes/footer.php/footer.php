<head>
     <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="../../assets/css/footer.css">
</head>
<footer>
    <div class="explore">
        <h1>Explore</h1>
        <ul>
            <li><a href="../index.php">Home</a></li>
            <li><a href="">Jelajahi</a></li>
            <li><a href="">Quiz</a></li>
        </ul>
    </div>
    <div class="contact">
        <h1>Contact</h1>
        <a href="https://gmail.com">sulapedia.info@gmail.com</a>
        <a href="https://wa.me/62881024501933">+6288-1024-5019-33</a>
        <div class="logo">
            <a href="https://instagram.com"><img src="../../assets/img/ig.png" alt="ig"></a>
            <a href="https://facebook.com"><img src="../../assets/img/fb.png" alt="fb"></a>
            <a href="https://x.com"><img src="../../assets/img/x.png" alt="x"></a>            
        </div>
    </div>

</footer>